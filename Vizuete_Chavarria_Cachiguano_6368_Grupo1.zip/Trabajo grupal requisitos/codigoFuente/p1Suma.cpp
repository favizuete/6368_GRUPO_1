

#include <conio.h>
#include <stdio.h>

int main()
{
    float n1, n2,suma;

    printf( "\nIntroduzca primer numero: " );
    scanf( "%f", &n1 );
    printf( "\nIntroduzca segundo numero: " );
    scanf( "%f", &n2 );
    suma = n1 + n2;
    printf( "\nLa suma es: %2.2f", suma );
    }
